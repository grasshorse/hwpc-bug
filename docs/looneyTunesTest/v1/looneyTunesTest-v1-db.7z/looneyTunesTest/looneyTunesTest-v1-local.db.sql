BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS contract_billing_records (
          id TEXT PRIMARY KEY,
          contractId TEXT NOT NULL,
          billingPeriodStart DATE NOT NULL,
          billingPeriodEnd DATE NOT NULL,
          amount DECIMAL(10,2) NOT NULL,
          status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'overdue', 'cancelled')),
          dueDate DATE NOT NULL,
          paidDate DATE,
          paymentMethod TEXT,
          notes TEXT,
          
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          
          FOREIGN KEY (contractId) REFERENCES service_contracts(id) ON DELETE CASCADE
        );
CREATE TABLE IF NOT EXISTS contract_events (
          id TEXT PRIMARY KEY,
          contractId TEXT NOT NULL,
          eventType TEXT NOT NULL CHECK (eventType IN ('created', 'paused', 'resumed', 'terminated', 'service_completed', 'billing_updated')),
          eventData TEXT,
          notes TEXT,
          createdBy TEXT,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          
          FOREIGN KEY (contractId) REFERENCES service_contracts(id) ON DELETE CASCADE
        );
CREATE TABLE IF NOT EXISTS customers (
              id TEXT PRIMARY KEY,
              name TEXT NOT NULL,
              email TEXT UNIQUE,
              phone TEXT,
              street TEXT,
              city TEXT,
              state TEXT,
              zipCode TEXT,
              lat REAL,
              lng REAL,
              serviceType TEXT,
              notes TEXT,
              isActive BOOLEAN DEFAULT 1,
              createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
              updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE IF NOT EXISTS routes (
              id TEXT PRIMARY KEY,
              name TEXT NOT NULL,
              description TEXT,
              startLocation TEXT,
              endLocation TEXT,
              estimatedDuration INTEGER,
              isActive BOOLEAN DEFAULT 1,
              createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
              updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE IF NOT EXISTS schema_migrations (
          version TEXT PRIMARY KEY,
          filename TEXT NOT NULL,
          executed_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
CREATE TABLE IF NOT EXISTS service_contracts (
          id TEXT PRIMARY KEY,
          customerId TEXT NOT NULL,
          contractType TEXT NOT NULL CHECK (contractType IN ('monthly', 'quarterly', 'event_based')),
          status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'paused', 'terminated', 'completed')),
          
          -- Contract Terms
          startDate DATE NOT NULL,
          endDate DATE,
          totalEvents INTEGER,
          remainingEvents INTEGER,
          
          -- Scheduling Configuration
          monthlyServiceDay INTEGER CHECK (monthlyServiceDay BETWEEN 1 AND 31),
          quarterlySchedule TEXT,
          eventInterval INTEGER,
          
          -- Service Details
          serviceType TEXT,
          serviceNotes TEXT,
          specialInstructions TEXT,
          
          -- Billing Information
          contractValue DECIMAL(10,2),
          billingCycle TEXT CHECK (billingCycle IN ('monthly', 'quarterly', 'per_service', 'upfront')),
          billingStatus TEXT DEFAULT 'current' CHECK (billingStatus IN ('current', 'overdue', 'suspended')),
          
          -- Metadata
          createdBy TEXT,
          pauseReason TEXT,
          pausedAt DATETIME,
          terminationReason TEXT,
          terminatedAt DATETIME,
          
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          
          FOREIGN KEY (customerId) REFERENCES customers(id) ON DELETE CASCADE
        );
CREATE TABLE IF NOT EXISTS tickets (
              id TEXT PRIMARY KEY,
              customerId TEXT NOT NULL,
              routeId TEXT,
              title TEXT NOT NULL,
              description TEXT,
              status TEXT DEFAULT 'open',
              priority TEXT DEFAULT 'medium',
              assignedTo TEXT,
              scheduledDate DATETIME,
              completedDate DATETIME,
              address TEXT,
              lat REAL,
              lng REAL,
              createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
              updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY (customerId) REFERENCES customers(id) ON DELETE CASCADE,
              FOREIGN KEY (routeId) REFERENCES routes(id) ON DELETE SET NULL
            );
CREATE TABLE IF NOT EXISTS users (
              id TEXT PRIMARY KEY,
              email TEXT UNIQUE NOT NULL,
              name TEXT NOT NULL,
              password_hash TEXT NOT NULL,
              roles TEXT DEFAULT '["user"]',
              preferences TEXT DEFAULT '{}',
              is_active BOOLEAN DEFAULT 1,
              last_login_at TEXT,
              createdAt TEXT NOT NULL,
              updatedAt TEXT NOT NULL
            );
INSERT INTO "customers" ("id","name","email","phone","street","city","state","zipCode","lat","lng","serviceType","notes","isActive","createdAt","updatedAt") VALUES ('64fcec34-150a-476f-804a-3e9072a7e6bf','Daffy Duck','daffy@2cld.com','130-850-1356','2384 120th Street','Winfield','IA','52659',41.122404,-91.4508,'Commercial','Gerling Repair',1,'2025-08-15T17:19:38.737Z','2025-08-15T17:19:38.737Z'),
 ('5895fdfd-4305-485a-b4da-9f2f8e20ef1a','Elmer Fudd','efudd@2cld.com','229-924-9482','2224 120th St','Winfield','IA','52659',41.13308,-91.48079,'Commercial','TH Twig, LLC',1,'2025-08-15T17:19:38.745Z','2025-08-15T17:19:38.745Z'),
 ('6c3aaf1e-86b4-4f96-8cc4-231f575bcf3a','Bugs Bunny','bugs@2cld.com','500-469-2164','2378 120th Street','Winfield','IA','52659',41.13326,-91.45204,'Residential','BooBoo Bunny Infestation.  contact booboo@conversehouse.com',1,'2025-08-15T17:19:38.749Z','2025-08-15T17:25:52.544Z'),
 ('335fa832-141a-4257-8478-506d508ce379','Porky Pig','ppig@2cld.com','979-520-5701','111 N Locust St','Winfield','IA','52659',41.12913,-91.43797,'Commercial','Grasshorse artist Porky Pig',1,'2025-08-15T17:19:38.752Z','2025-08-15T17:19:38.752Z'),
 ('934d89d3-0d77-4051-ac83-a68d3f8e76b6','Wile E. Coyote','wec@2cld.com','713-177-0465','2416 Rownd Street','Cedar Falls','IA','50613',42.51606,-92.42056,'Residential','WEC Super Genius',1,'2025-08-15T17:19:38.756Z','2025-08-15T17:19:38.756Z'),
 ('fe05bd6a-b2f4-4523-9583-2d3967ba05d0','Road Runner','rr@2cld.com','036-624-6236','2821 Horseshoe Dr','Cedar Falls','IA','50613',42.50313,-92.47982,'Commercial','Fletcher Motor Co., LLC',1,'2025-08-15T17:19:38.760Z','2025-08-15T17:19:38.760Z'),
 ('1320076e-867a-45c8-a944-55d0c433163e','Tasmanian Devil','tazd@2cld.com','483-022-5584','200 State St Suite 201-C','Cedar Falls','IA','50613',42.53634,-92.4439,'Commercial','Taz at RiverPlace co-working',1,'2025-08-15T17:19:38.766Z','2025-08-15T17:19:38.766Z'),
 ('88d84fe3-e10d-4642-bb14-1e77f92ca5a1','Foghorn Leghorn','foghorn@2cld.com','391-192-1496','1605 Summit Estates','O''Fallon','MO','63366',38.82889,-90.7596,'Residential','guscamp https://guscamp-2025.conversehouse.com/',1,'2025-08-15T17:19:38.769Z','2025-08-15T17:19:38.769Z'),
 ('33dfd7ab-fb0f-4409-b058-e49fd95ee7d8','Yosemite Sam','ysam@2cld.com','701-843-5635','108 S Main St','O''Fallon','MO','63366',38.81077,-90.69967,'Municipal','GoodWood Drinks and Food',1,'2025-08-15T17:19:38.773Z','2025-08-15T17:19:38.773Z'),
 ('df44c5be-2f59-4c05-9804-febfaaff5f53','Marvin T. Martian','mtm@2cld.com','227-655-6598','330 Sonderen St','O''Fallon','MO','63366',38.80864,-90.69417,'Municipal','Good News Brewing and Pizza',1,'2025-08-15T17:19:38.777Z','2025-08-15T17:19:38.777Z');
INSERT INTO "routes" ("id","name","description","startLocation","endLocation","estimatedDuration","isActive","createdAt","updatedAt") VALUES ('1f62999b-074e-49a7-b73b-03da4cf0f480','LooneyTunes Route 1 - Winfield Test','Test Winfield','2378 120th Street, Winfield','2378 120th Street Winfield',60,1,'2025-08-15T17:19:38.784Z','2025-08-15T17:19:38.784Z'),
 ('c3c4f498-8a5d-448e-9bb3-2492ab6185a3','LooneyTunes Route 2 - Cedar Falls Test','Test Cedar Falls','2416 Rownd Street, Cedar Falls','2416 Rownd Street, Cedar Falls',120,1,'2025-08-15T17:19:38.787Z','2025-08-15T17:19:38.787Z'),
 ('62ebc039-bd9a-497e-8af3-660c3b05103a','LooneyTunes Route 3 - O''Fallon Test','Test O''Fallon','1605 Summit Estates, O''Fallon','1605 Summit Estates, O''Fallon',160,1,'2025-08-15T17:19:38.790Z','2025-08-15T17:19:38.790Z');
INSERT INTO "schema_migrations" ("version","filename","executed_at") VALUES ('001','001_add_service_contracts.sql','2025-08-14 12:05:26');
INSERT INTO "tickets" ("id","customerId","routeId","title","description","status","priority","assignedTo","scheduledDate","completedDate","address","lat","lng","createdAt","updatedAt") VALUES ('d201ad5a-e3c6-4d7c-87a3-ecb6b13f5bec','1320076e-867a-45c8-a944-55d0c433163e',NULL,'Cleaning - adhaero summa','Hic templum laborum. Curia exercitationem administratio caterva. Admitto antiquus inventore voveo collum sodalitas.','in_progress','urgent','John Smith','2025-08-21T10:10:10.213Z',NULL,'481 Alexandra Road',43.7833,-76.6285,'2025-08-15T17:19:38.799Z','2025-08-15T17:19:38.799Z'),
 ('1a21e788-0c9b-4b61-9d05-74233422b769','64fcec34-150a-476f-804a-3e9072a7e6bf','1f62999b-074e-49a7-b73b-03da4cf0f480','Removal - advenio venia','Defaeco velum absque thorax ara sit patria. Contra armarium adnuo. Surgo nemo victus teres decipio demonstro synagoga vere explicabo perspiciatis.','open','urgent','Sarah Johnson','2025-09-26T23:19:49.202Z',NULL,'8888 Chestnut Street',26.7655,-74.3277,'2025-08-15T17:19:38.803Z','2025-08-15T17:19:38.803Z'),
 ('a36add5b-63f7-492f-969a-25e8e84f6356','335fa832-141a-4257-8478-506d508ce379','62ebc039-bd9a-497e-8af3-660c3b05103a','Repair - deficio arto','Clamo vallum cupiditas. Ocer alienus sumptus tamisium claro verecundia minus vociferor. Arguo decens conservo.','cancelled','urgent','Sarah Johnson','2025-08-27T12:28:30.768Z',NULL,'49714 Reba Course',35.6733,-74.7344,'2025-08-15T17:19:38.807Z','2025-08-15T17:19:38.807Z'),
 ('c7d39ee3-4f7e-49b6-8150-7485939b3a8b','5895fdfd-4305-485a-b4da-9f2f8e20ef1a',NULL,'Emergency - absum vos','A vinitor tondeo suscipit. Tabella tres ater conspergo charisma arbitro pax. Aeneus adamo adnuo voveo tantum vulgivagus custodia autus.','cancelled','urgent','David Brown','2025-08-30T19:03:06.947Z',NULL,'134 Runolfsson Way',30.1532,-68.2161,'2025-08-15T17:19:38.811Z','2025-08-15T17:19:38.811Z'),
 ('263ca49f-9660-4509-a54b-79ce28f4ec2d','335fa832-141a-4257-8478-506d508ce379','1f62999b-074e-49a7-b73b-03da4cf0f480','Repair - suppellex est','Cultura clam bene conforto. Artificiose alveus spoliatio strues. Verto suffoco caelestis voluptate vulgo vulnus maxime venustas.','completed','medium','Chris Anderson','2025-07-25T15:27:23.000Z','2025-07-29T09:41:54.178Z','49714 Reba Course',35.6733,-74.7344,'2025-08-15T17:19:38.815Z','2025-08-15T17:19:38.815Z'),
 ('82da92d6-5fb0-4ac3-80e6-7d58f03315c7','934d89d3-0d77-4051-ac83-a68d3f8e76b6','1f62999b-074e-49a7-b73b-03da4cf0f480','Removal - canto conitor','Aegrotatio adnuo deorsum. Voluptatum validus ancilla cicuta ambulo nemo audax cinis tenax synagoga. Decet abduco abbas alioqui arceo ait torrens utilis via dapifer.','open','medium','Sarah Johnson','2025-09-03T10:04:26.545Z',NULL,'1458 Railroad Street',37.5345,-70.5574,'2025-08-15T17:19:38.818Z','2025-08-15T17:19:38.818Z'),
 ('87750fad-eb4a-4f95-9e70-64e1f7516214','fe05bd6a-b2f4-4523-9583-2d3967ba05d0',NULL,'Emergency - terminatio viridis','Conitor agnitio aggero tergum clementia subnecto officia texo utroque acquiro. Quas aestivus vaco decens. Casso officiis attero sit terebro capto magni truculenter deinde terminatio.','open','medium',NULL,'2025-08-16T06:44:10.506Z',NULL,'5203 School Street',34.7182,-69.1893,'2025-08-15T17:19:38.822Z','2025-08-15T17:19:38.822Z'),
 ('00614e91-0ba8-4cff-b7e3-63c6f77a61aa','df44c5be-2f59-4c05-9804-febfaaff5f53','c3c4f498-8a5d-448e-9bb3-2492ab6185a3','Cleaning - deinde nemo','Combibo suscipio quibusdam verbum fuga valde admoneo. Civis careo absconditus avaritia. Sortitus truculenter paulatim iure conatus corpus audeo textor.','open','low','John Smith','2025-09-29T15:17:42.902Z',NULL,'34153 The Green',39.6892,-92.8775,'2025-08-15T17:19:38.826Z','2025-08-15T17:19:38.826Z'),
 ('03e1520a-3109-4e18-863d-cb18376bd28c','33dfd7ab-fb0f-4409-b058-e49fd95ee7d8','62ebc039-bd9a-497e-8af3-660c3b05103a','Consultation - voluptatum deputo','Desipio una aqua. Rerum curatio patria testimonium conicio contego clarus. Coma suffragium deprimo tergeo acquiro stella confugo tui.','cancelled','urgent','Chris Anderson','2025-08-15T06:54:43.375Z',NULL,'354 Oda Way',25.3655,-118.2043,'2025-08-15T17:19:38.829Z','2025-08-15T17:19:38.829Z'),
 ('0b66b414-e235-4b12-a966-e56ed3b9c552','fe05bd6a-b2f4-4523-9583-2d3967ba05d0','62ebc039-bd9a-497e-8af3-660c3b05103a','Cleaning - spargo utrimque','Constans cauda thermae nisi. Curtus bonus perferendis. Verto quo argentum pecto suscipio pax terebro crudelis auctor.','in_progress','high','Chris Anderson','2025-08-27T23:00:36.018Z',NULL,'5203 School Street',34.7182,-69.1893,'2025-08-15T17:19:38.833Z','2025-08-15T17:19:38.833Z'),
 ('35267b45-dea6-474c-9126-dc2202ce967f','64fcec34-150a-476f-804a-3e9072a7e6bf','1f62999b-074e-49a7-b73b-03da4cf0f480','Removal - acerbitas nam','Aeger adhuc suscipio deorsum rem ars compello. Utor correptius correptius celo amiculum debitis omnis cumque claustrum. Uxor vinculum ciminatio quod utpote.','open','medium','Amanda Martinez','2025-08-10T18:51:33.667Z',NULL,'8888 Chestnut Street',26.7655,-74.3277,'2025-08-15T17:19:38.837Z','2025-08-15T17:19:38.837Z'),
 ('4f9fed3e-f7d9-4f46-a296-fe0be10b732b','6c3aaf1e-86b4-4f96-8cc4-231f575bcf3a','62ebc039-bd9a-497e-8af3-660c3b05103a','Inspection - turbo uredo','Barba subito correptius temeritas officia. Rem dolore voluptatum sortitus cruentus tego uredo. Nulla porro alias tot.','completed','high','David Brown','2025-07-17T20:41:27.875Z','2025-07-23T14:28:58.065Z','2261 E 6th Avenue',31.0564,-97.899,'2025-08-15T17:19:38.840Z','2025-08-15T17:19:38.840Z'),
 ('153da2fe-5d8d-4195-a825-481aaa859e56','64fcec34-150a-476f-804a-3e9072a7e6bf','c3c4f498-8a5d-448e-9bb3-2492ab6185a3','Removal - allatus quae','Odit aggero aduro vetus repellendus undique audeo volva. Autus officia thymum paulatim varius demitto. Voluptatem artificiose campana copiose.','completed','high','Sarah Johnson','2025-09-13T17:15:40.350Z','2025-09-17T02:56:03.789Z','8888 Chestnut Street',26.7655,-74.3277,'2025-08-15T17:19:38.844Z','2025-08-15T17:19:38.844Z'),
 ('75b04ab1-1f64-4aa1-a26a-6f34b94a60b3','fe05bd6a-b2f4-4523-9583-2d3967ba05d0','1f62999b-074e-49a7-b73b-03da4cf0f480','Testing - reiciendis cultura','Ara defleo suffragium thesis decipio laboriosam ullus articulus suus angustus. Ademptio suadeo veritas tergeo tergo demitto terebro bardus vix causa. Contego depraedor exercitationem theca.','in_progress','urgent','John Smith','2025-10-10T18:23:31.092Z',NULL,'5203 School Street',34.7182,-69.1893,'2025-08-15T17:19:38.847Z','2025-08-15T17:19:38.847Z'),
 ('4e727691-e6db-4909-8ab6-e57247d60f6e','5895fdfd-4305-485a-b4da-9f2f8e20ef1a','62ebc039-bd9a-497e-8af3-660c3b05103a','Inspection - ventito temeritas','Vespillo carbo conservo decimus culpo. Paulatim repellendus animus. Cariosus canto constans tredecim argentum aliquam conculco tabgo appello.','completed','low','David Brown','2025-10-07T12:17:37.440Z','2025-10-07T14:44:03.005Z','134 Runolfsson Way',30.1532,-68.2161,'2025-08-15T17:19:38.851Z','2025-08-15T17:19:38.851Z');
INSERT INTO "users" ("id","email","name","password_hash","roles","preferences","is_active","last_login_at","createdAt","updatedAt") VALUES ('f1ae3d11-ef72-4076-860f-518f0f082098','admin@2cld.com','Admin User','$2b$10$GNwpodUwSNOv4/nFIV82h.sFYfx1gpo.mOsW4oCM8GBbRMujdtSHW','["admin","user"]','{"theme":"dark","notifications":true,"language":"en","timezone":"America/New_York"}',1,NULL,'2025-08-15T17:19:39.080Z','2025-08-15T17:19:39.080Z'),
 ('4b14e1b3-d3a1-4de4-aa67-264af5a98b1d','user@2cld.com','Regular User','$2b$10$zcWx4p1fIN4xorB8imcrt.vodpS67eRMWMg96Q8cSUOHJoZNieati','["user"]','{"theme":"light","notifications":false,"language":"en","timezone":"America/Los_Angeles"}',1,NULL,'2025-08-15T17:19:39.085Z','2025-08-15T17:19:39.085Z'),
 ('cdbb2765-5c11-4011-abdb-6d41aedb0c96','christrees@gmail.com','Chris Trees','$2b$10$3zXlwkqYvk0xjpvmCDKCtOqEDWZJQhKbqeZdzYiNH5HlycewFfcou','["manager","user"]','{"theme":"dark","notifications":false,"language":"es","timezone":"America/Phoenix","dashboardLayout":"grid","itemsPerPage":50}',1,'','2025-08-15T17:19:39.088Z','2025-08-15T17:19:39.088Z');
CREATE INDEX idx_contract_billing_contract ON contract_billing_records(contractId);
CREATE INDEX idx_contract_billing_due_date ON contract_billing_records(dueDate);
CREATE INDEX idx_contract_billing_period_end ON contract_billing_records(billingPeriodEnd);
CREATE INDEX idx_contract_billing_period_start ON contract_billing_records(billingPeriodStart);
CREATE INDEX idx_contract_billing_status ON contract_billing_records(status);
CREATE INDEX idx_contract_events_contract ON contract_events(contractId);
CREATE INDEX idx_contract_events_created ON contract_events(createdAt);
CREATE INDEX idx_contract_events_type ON contract_events(eventType);
CREATE INDEX idx_customers_active ON customers(isActive);
CREATE INDEX idx_customers_email ON customers(email);
CREATE INDEX idx_customers_name ON customers(name);
CREATE INDEX idx_routes_active ON routes(isActive);
CREATE INDEX idx_routes_name ON routes(name);
CREATE INDEX idx_service_contracts_billing_status ON service_contracts(billingStatus);
CREATE INDEX idx_service_contracts_created ON service_contracts(createdAt);
CREATE INDEX idx_service_contracts_customer ON service_contracts(customerId);
CREATE INDEX idx_service_contracts_end_date ON service_contracts(endDate);
CREATE INDEX idx_service_contracts_start_date ON service_contracts(startDate);
CREATE INDEX idx_service_contracts_status ON service_contracts(status);
CREATE INDEX idx_service_contracts_type ON service_contracts(contractType);
CREATE INDEX idx_tickets_created ON tickets(createdAt);
CREATE INDEX idx_tickets_customer ON tickets(customerId);
CREATE INDEX idx_tickets_priority ON tickets(priority);
CREATE INDEX idx_tickets_route ON tickets(routeId);
CREATE INDEX idx_tickets_scheduled ON tickets(scheduledDate);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_users_active ON users(is_active);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_name ON users(name);
CREATE INDEX idx_users_roles ON users(roles);
COMMIT;
